﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataBinding
{
    public class CustomerService
    {
        public void GetData(string custid, Customer ce)
        {
            string connectsring = ConfigurationManager.ConnectionStrings
            ["labdemoconnectstring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectsring);
            SqlCommand cmd = new SqlCommand("select * from Amit.cust where custid = '" + custid + "'", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                ce.CustID = dr["custid"].ToString();
                ce.CustName = dr["custname"].ToString();
                ce.CreditLimit =
                double.Parse(dr["credlimit"].ToString());
                ce.Premium = bool.Parse(dr["ispremium"].ToString());
            }
            dr.Close(); con.Close();
        }
        public void SaveChanges(Customer c)
        {
            string connectsring = ConfigurationManager.ConnectionStrings
            ["labdemoconnectstring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectsring);
            string sql = "update Amit.cust set custname = '" + c.CustName + "',credlimit = " + c.CreditLimit.ToString() + ",ispremium = "
            + (c.Premium == true ? 1 : 0).ToString()
            + " where custid = '" + c.CustID + "'";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
        }
    }
}
