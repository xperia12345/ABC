﻿create table Amit.cust
(
custid varchar(10) primary key,
custname varchar(50),
credlimit numeric(10,2),
IsPremium bit
)
insert into Amit.cust values('am','amit',10000,1)
insert into Amit.cust values('sum','sumit',15000,1)
insert into Amit.cust values('sacdd','sachin',25000,0)

select * from Amit.cust