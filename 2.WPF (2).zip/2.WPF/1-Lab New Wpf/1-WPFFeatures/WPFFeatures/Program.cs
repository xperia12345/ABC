﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;



namespace WPFFeatures
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Window mainWindow = new Window();
            mainWindow.Title = "WPF Application";
            Button button1 = new Button();
            button1.Content = "Click Me!";
            mainWindow.Content = button1;
            Application app = new Application();
            app.Run(mainWindow);
        }
    }
}
