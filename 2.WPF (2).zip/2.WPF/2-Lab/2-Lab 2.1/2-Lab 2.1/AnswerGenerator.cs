﻿using System;

namespace _2_Lab
{
    internal class AnswerGenerator
    {
        internal string GetRandomAnswer(string text)
        {
            throw new NotImplementedException();
        }
    }
}