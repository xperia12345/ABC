﻿namespace Lab_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnnew = new System.Windows.Forms.Button();
            this.emptype = new System.Windows.Forms.GroupBox();
            this.Payroll = new System.Windows.Forms.RadioButton();
            this.Consultant = new System.Windows.Forms.RadioButton();
            this.empno = new System.Windows.Forms.TextBox();
            this.empname = new System.Windows.Forms.TextBox();
            this.empsal = new System.Windows.Forms.TextBox();
            this.Delete = new System.Windows.Forms.Button();
            this.emptype.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(65, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Employee Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Salary";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(85, 192);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "Query";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnquery);
            // 
            // btnsave
            // 
            this.btnsave.Location = new System.Drawing.Point(372, 192);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 23);
            this.btnsave.TabIndex = 4;
            this.btnsave.Text = "Save";
            this.btnsave.UseVisualStyleBackColor = true;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnnew
            // 
            this.btnnew.Location = new System.Drawing.Point(273, 192);
            this.btnnew.Name = "btnnew";
            this.btnnew.Size = new System.Drawing.Size(75, 23);
            this.btnnew.TabIndex = 5;
            this.btnnew.Text = "New";
            this.btnnew.UseVisualStyleBackColor = true;
            this.btnnew.Click += new System.EventHandler(this.btnnew_Click);
            // 
            // emptype
            // 
            this.emptype.Controls.Add(this.Payroll);
            this.emptype.Controls.Add(this.Consultant);
            this.emptype.Location = new System.Drawing.Point(372, 70);
            this.emptype.Name = "emptype";
            this.emptype.Size = new System.Drawing.Size(109, 70);
            this.emptype.TabIndex = 6;
            this.emptype.TabStop = false;
            this.emptype.Text = "Employee Type";
            // 
            // Payroll
            // 
            this.Payroll.AutoSize = true;
            this.Payroll.Location = new System.Drawing.Point(12, 19);
            this.Payroll.Name = "Payroll";
            this.Payroll.Size = new System.Drawing.Size(56, 17);
            this.Payroll.TabIndex = 1;
            this.Payroll.TabStop = true;
            this.Payroll.Text = "Payroll";
            this.Payroll.UseVisualStyleBackColor = true;
            // 
            // Consultant
            // 
            this.Consultant.AutoSize = true;
            this.Consultant.Location = new System.Drawing.Point(12, 42);
            this.Consultant.Name = "Consultant";
            this.Consultant.Size = new System.Drawing.Size(75, 17);
            this.Consultant.TabIndex = 0;
            this.Consultant.TabStop = true;
            this.Consultant.Text = "Consultant";
            this.Consultant.UseVisualStyleBackColor = true;
            // 
            // empno
            // 
            this.empno.Location = new System.Drawing.Point(166, 76);
            this.empno.Name = "empno";
            this.empno.Size = new System.Drawing.Size(100, 20);
            this.empno.TabIndex = 7;
            // 
            // empname
            // 
            this.empname.Location = new System.Drawing.Point(166, 106);
            this.empname.Name = "empname";
            this.empname.Size = new System.Drawing.Size(100, 20);
            this.empname.TabIndex = 8;
            // 
            // empsal
            // 
            this.empsal.Location = new System.Drawing.Point(166, 136);
            this.empsal.Name = "empsal";
            this.empsal.Size = new System.Drawing.Size(100, 20);
            this.empsal.TabIndex = 9;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(181, 192);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(75, 23);
            this.Delete.TabIndex = 10;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 274);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.empsal);
            this.Controls.Add(this.empname);
            this.Controls.Add(this.empno);
            this.Controls.Add(this.emptype);
            this.Controls.Add(this.btnnew);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "EmployeeForm";
            this.Load += new System.EventHandler(this.EmployeeForm);
            this.emptype.ResumeLayout(false);
            this.emptype.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnnew;
        private System.Windows.Forms.GroupBox emptype;
        private System.Windows.Forms.RadioButton Payroll;
        private System.Windows.Forms.RadioButton Consultant;
        private System.Windows.Forms.TextBox empno;
        private System.Windows.Forms.TextBox empname;
        private System.Windows.Forms.TextBox empsal;
        private System.Windows.Forms.Button Delete;
    }
}

