﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Lab_1
{
    public partial class Form1 : Form
    {
        SqlConnection con = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void EmployeeForm(object sender, EventArgs e)
        {
            con = new SqlConnection(@"server=NDAMSSQL\SQLILEARN;database=Training_24Oct18_Pune;" +"user id=sqluser;password=sqluser");
            con.Open();
        }

        private void btnquery(object sender, EventArgs e)
        {
            try
            {
                SqlDataReader dreader = null;
                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById", con);
                cmd.CommandType = CommandType.StoredProcedure;
                //define procedure parameter
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);
                //assign parameter value
                cmd.Parameters["@eno"].Value = int.Parse(empno.Text);
                //execute
                dreader = cmd.ExecuteReader();
                //if employee record found
                if (dreader.Read())
                {
                    empname.Text = dreader["empname"].ToString();
                    empsal.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P")
                        Payroll.Checked = true;
                    else
                        Consultant.Checked = true;
                }
                else
                {
                    btnnew_Click(btnnew, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }



        private void btnnew_Click(object sender, EventArgs e)
        {
            empno.Text = "";
            empname.Text = "";
            empsal.Text = "";
            empno.Focus();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            try
            {
                //The Insert DML to add employee record
                SqlCommand cmd = new SqlCommand("insert into employee values(@eno, @enm, @esal, @etyp)", con);
                //The Parameters
                cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@esal", SqlDbType.Decimal);
                cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);
                //Assigning Values to parameters
                cmd.Parameters["@eno"].Value = empno.Text;
                cmd.Parameters["@enm"].Value = empname.Text;
                cmd.Parameters["@esal"].Value = Convert.ToDecimal(empsal.Text);
                cmd.Parameters["@etyp"].Value = Payroll.Checked == true ? "P" : "C";
                //Execute Insert ....
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            try
            {
              
                SqlCommand cmd = new SqlCommand("Delete employee where empno = @eno", con);
                cmd.Parameters.Add("@eno", SqlDbType.Int);

                cmd.Parameters["@eno"].Value = empno.Text;
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Deleted");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }

        }
    }
}

