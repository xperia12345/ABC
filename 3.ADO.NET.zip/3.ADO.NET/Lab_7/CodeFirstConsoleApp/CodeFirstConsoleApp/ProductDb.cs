﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstConsoleApp
{
    class ProductDb : DbContext
    {
        public ProductDb() : base("name=con1")
        {

        }
        public virtual DbSet<Product7> Products { get; set; }
    }
}
