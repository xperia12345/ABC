﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseFirstConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_24Oct18_PuneEntities dbContext = new Training_24Oct18_PuneEntities();

            //Displaying all Albums detail

            var albums = dbContext.Albums;

            foreach (Album a in albums)
            {
                Console.WriteLine(a.AlbumID + "\t" + a.Name + "\t" + a.Price);
            }



            ////Add album

            //Album album = new Album
            //{
            //    AlbumID = 104,
            //    Name = "Best of Atif Aslam",
            //    Genre = "Sofy",
            //    Year = "2015",
            //    Price = 300
            //};

            //dbContext.Albums.Add(album);
            //dbContext.SaveChanges();

            //Console.WriteLine("Album Details Added Successfully!");

        }
    }
}
