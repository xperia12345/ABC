﻿select * from Product7

create Table Album
(
	[AlbumID] int primary key not null,
	[Name] varchar(20),
	[Genre] varchar(20),
	[Year] varchar(20),
	[Price] decimal
);


insert into Album values(101,'Bolo Ta Ra Ra..','Punjabi-Music',1995,300),
						(102,'Young Tarang','Pakistani pop',1984,200),
						(103,'Best Of Arijit Singh','Romantic-Music',2016,250);

select top 100 [AlbumID],[Name],[Genre],[Year],[Price]
from Album