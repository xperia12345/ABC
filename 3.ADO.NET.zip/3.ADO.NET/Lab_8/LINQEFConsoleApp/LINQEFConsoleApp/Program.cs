﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQEFConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Initialize Object dbContext
            Training_24Oct18_PuneEntities dbContext = new Training_24Oct18_PuneEntities();

            #region Linq Queries
            ////-------------------Q1------------------------------------------------------------------------------------
            //var query1 = from staff in dbContext.staff_master
            //            select staff;

            ////Displaying details from Staff_Master Entity
            //foreach (staff_master s in query1)
            //{
            //    Console.WriteLine("Staff Code: {0}, Name: {1}, Hire Date: {2}", s.Staff_code, s.Staff_name, s.Hire_date);
            //}

            ////-------------------Q2------------------------------------------------------------------------------------
            //var query2 = from staff in dbContext.staff_master
            //            where staff.Staff_sal > 30000
            //            select staff;

            //foreach (staff_master s in query2)
            //{
            //    Console.WriteLine("Staff Code: {0}, Name: {1}, Salary: {2}", s.Staff_code, s.Staff_name, s.Staff_sal);
            //}

            ////-------------------Q3------------------------------------------------------------------------------------
            //var query3 = from student in dbContext.Student_master
            //             where student.Address != null
            //             select student;

            //foreach (Student_master s in query3)
            //{
            //    Console.WriteLine("Student Name: {0}, Address: {1}", s.Stud_Name, s.Address);
            //}

            ////-------------------Q3------------------------------------------------------------------------------------
            //var query3 = from student in dbContext.Student_master
            //             where student.Stud_Name != null
            //             select student;

            //foreach (Student_master s in query3)
            //{
            //    Console.WriteLine("Student Name: {0}, Department Code: {1}, DOB: {2}", s.Stud_Name, s.Dept_Code, s.Stud_Dob);
            //}

            ////-------------------Q3------------------------------------------------------------------------------------
            //var query3 = from student in dbContext.Student_master
            //             where student.Address == "Bangalore"
            //             select student;
            //Console.WriteLine(query3.Count());

            //var query3 = dbContext.Student_master.Count(s => s.Address == "Bangalore");
            //Console.WriteLine(query3);

            //////-------------------Q4------------------------------------------------------------------------------------
            //var res = dbContext.Staff_Master.Average(s => s.Salary);
            //var query4 = dbContext.Staff_Master.Where(s => s.Salary > res);
            //Console.WriteLine("Average Salary: "+res);
            //foreach (Staff_Master s in query4)
            //{
            //    Console.WriteLine("Staff Name: {0}, Salary: {1}", s.Staff_Name, s.Salary);
            //}        

            #endregion

            #region Practice CRUD



            ////To ADD a Record 

            ////Initializing a student object
            //Student_master student = new Student_master
            //{
            //    Stud_Code = 1055,
            //    Stud_Name = "Suresh M",
            //    Dept_Code = 10,
            //    Stud_Dob = Convert.ToDateTime("08/08/1985"),
            //    Address = "Mumbai"
            //};

            ////Adding the student object to EntitySet
            //dbContext.Student_master.Add(student);

            ////Saving Changes to Database
            //dbContext.SaveChanges();
            //Console.WriteLine("Student data Saved Successfully");
            //Console.ReadLine();




            ////To Update a Record 

            ////Acquiring the Object which need to be Updated
            //Student_master student = (from s in dbContext.Student_master.Where
            //                            (s => s.Stud_Code == 1020)
            //                          select s).FirstOrDefault();
            //if (student != null)
            //{
            //    student.Address = "Bangalore";
            //    dbContext.SaveChanges();
            //    Console.WriteLine("Student Data Updated Successfully");
            //}
            //else
            //{
            //    Console.WriteLine("Cannot Update Student\nStudent Not Available");
            //}




            ////To Delete a Record 

            ////Acquiring the Object which need to be Deleted
            //Student_master studentToDelete = (from s in dbContext.Student_master.Where
            //                                    (s => s.Stud_Code == 1020)
            //                                 select s).FirstOrDefault();
            //if (studentToDelete != null)
            //{
            //    //Removing the record from the entity set
            //    dbContext.Student_master.Remove(studentToDelete);
            //    dbContext.SaveChanges();
            //    Console.WriteLine("Data Deleted Successfully");
            //}
            //else
            //{
            //    Console.WriteLine("Cannot Delete Student\nStudent Not Available");
            //}


            #endregion

            #region To-Do CRUD 
            char flag;
            do
            {
                Console.WriteLine("1 <-- Add\n2 <-- Update\n3 <-- Search\n4 <-- Delete");
            Console.Write("Enter Your Choice: ");
            int ch = Convert.ToInt32(Console.ReadLine());
            
            
                switch (ch)
                {
                    case 1:
                        //To ADD a Record 

                        //Initializing a employee object
                        Employee employeeToAdd = new Employee
                        {
                            ID = 101,
                            Name = "John Doe",
                            DOB = Convert.ToDateTime("08/08/1985"),
                            DOJ = Convert.ToDateTime("11/06/2017"),
                            Designation = "Analyst",
                            Salary = 20000
                        };

                        //Adding the employee object to EntitySet
                        dbContext.Employees.Add(employeeToAdd);

                        //Saving Changes to Database
                        dbContext.SaveChanges();
                        Console.WriteLine("Employee data Saved Successfully");
                        Console.ReadLine();
                        break;

                    case 2:
                        //To Update a Record 

                        //Acquiring the Object which need to be Updated
                        Console.Write("Enter the Id of employee to be updated: ");
                        int idToUpdate = Convert.ToInt32(Console.ReadLine());
                        Employee studentToUpdate = (from e in dbContext.Employees.Where
                                                    (e => e.ID == idToUpdate)
                                                    select e).FirstOrDefault();
                        if (studentToUpdate != null)
                        {
                            studentToUpdate.Salary = 15500;
                            dbContext.SaveChanges();
                            Console.WriteLine("Employee Data Updated Successfully");
                        }
                        else
                        {
                            Console.WriteLine("Cannot Update Employee\nEmployee Not Available");
                        }
                        break;

                    case 3:
                        //To Search a Record 

                        //Acquiring the Object which need to be Searched
                        Console.Write("Enter the Id of employee to be updated: ");
                        int idToSearch = Convert.ToInt32(Console.ReadLine());
                        Employee employeeToSearch = (from e in dbContext.Employees.Where
                                                            (e => e.ID == idToSearch)
                                                     select e).FirstOrDefault();
                        if (employeeToSearch != null)
                        {
                            //Removing the record from the entity set
                            dbContext.SaveChanges();
                            Console.WriteLine("Data Searched for ID: {0} is \nName: {1} \nDOB: {2} \nDesignation: {3} \nSalary: {4}",
                                idToSearch, employeeToSearch.Name, employeeToSearch.DOB, employeeToSearch.Designation,
                                employeeToSearch.Salary);
                        }
                        else
                        {
                            Console.WriteLine("Cannot Delete Employee\nEmployee Not Available");
                        }
                        break;

                    case 4:
                        //To Delete a Record 

                        //Acquiring the Object which need to be Deleted
                        Console.Write("Enter the Id of employee to be updated: ");
                        int idToDelete = Convert.ToInt32(Console.ReadLine());
                        Employee employeeToDelete = (from e in dbContext.Employees.Where
                                                            (e => e.ID == idToDelete)
                                                     select e).FirstOrDefault();
                        if (employeeToDelete != null)
                        {
                            //Removing the record from the entity set
                            dbContext.Employees.Remove(employeeToDelete);
                            dbContext.SaveChanges();
                            Console.WriteLine("Data Deleted Successfully");
                        }
                        else
                        {
                            Console.WriteLine("Cannot Delete Employee\nEmployee Not Available");
                        }
                        break;

                    default:
                        Console.WriteLine("Entered Choice is Invalid");
                        break;
                }
                Console.WriteLine("Do you want to continue(Y/N):");
                flag = Convert.ToChar(Console.ReadLine());
            } while (flag == 'y' | flag =='Y' );
            
            

            #endregion
        }
    }
}
