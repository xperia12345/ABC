﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retest.Entities;
using Retest.Exceptions;
using System.Data.SqlClient;
using System.Configuration;

///<summary>
///      File                 : RetestManagementSystem
///      Author Name          : Kundan Maurya
///      Desc                 : Program to define respective function in Data Access layer.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

namespace Restests.DAL
{
    public class StudDAL
    {
        //Declaring SqlConnection object reference
        SqlConnection conn = null;

        //Declaring SqlCommand object reference
        SqlCommand cmd = null;

        //Declaring Data Reader object reference
        SqlDataReader dr = null;

        public StudDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn1"].ConnectionString);
        }

        //DAL Method to insert data in product table using Stored Procedure 

        public bool InsertDAL(StudEntity objEntity)
        {
            bool isInserted = false;
            try
            {
                cmd = new SqlCommand("Insert_student", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", objEntity.Name);
                cmd.Parameters.AddWithValue("@Class", objEntity.Class);
                cmd.Parameters.AddWithValue("@Marks", objEntity.Mark);
                cmd.Parameters.AddWithValue("@Gender", objEntity.Gender);
                cmd.Parameters.AddWithValue("@Address", objEntity.Address);
                conn.Open();
                cmd.ExecuteNonQuery();

            }
            catch (StudExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return isInserted;
        }

        //DAL Method to Update data in product table using Stored Procedure 
        public bool UpdateDAL(StudEntity objEntity)
        {
            bool isUpdate = false;
            try
            {
                cmd = new SqlCommand("Update_student", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", objEntity.ID);
                cmd.Parameters.AddWithValue("@Name", objEntity.Name);
                cmd.Parameters.AddWithValue("@Class", objEntity.Class);
                cmd.Parameters.AddWithValue("@Marks", objEntity.Mark);
                cmd.Parameters.AddWithValue("@Gender", objEntity.Gender);
                cmd.Parameters.AddWithValue("@Address", objEntity.Address);
                conn.Open();
                cmd.ExecuteNonQuery();

            }
            catch (StudExceptions ex)
            {
                throw;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return isUpdate;
        }

        //DAL Method to Delete data from product table using Stored Procedure 

        public bool DeleteDAL(int ID)
        {
            bool isDelete = false;
            try
            {
                cmd = new SqlCommand("Delete_student", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID",ID);            
                conn.Open();
                cmd.ExecuteNonQuery();

            }
            catch (StudExceptions ex)
            {
                throw;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return isDelete;
        }

        //DAL Method to Select and populate data from product table 

        public List<StudEntity> SelectDAL()
        {
            List<StudEntity> objlist = new List<StudEntity>();
            try
            {
                cmd = new SqlCommand("select * from maurya.student", conn);
                conn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        StudEntity p = new StudEntity();
                        p.ID = Convert.ToInt32(dr[0]);
                        p.Name = dr[1].ToString();
                        p.Class = Convert.ToInt32(dr[2]);
                        p.Mark = Convert.ToInt32(dr[3]);
                        p.Gender = dr[4].ToString();
                        p.Address = dr[5].ToString();
                        objlist.Add(p);
                    }
                }
                dr.Close();
            }
            catch (StudExceptions ex)
            {
                throw;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return objlist;
        }
    }
}
