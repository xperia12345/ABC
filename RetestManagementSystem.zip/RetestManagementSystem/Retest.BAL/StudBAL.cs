﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retest.Entities;
using Retest.Exceptions;
using Restests.DAL;

///<summary>
///      File                 : RetestManagementSystem
///      Author Name          : Kundan Maurya
///      Desc                 : Program for Business Logic
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

namespace Retest.BAL
{
    public class StudBAL
    {
        private static bool IsInputValid(StudEntity objstudBL)
        {
            StringBuilder sb = new StringBuilder();
            bool validstud = true;
            if (objstudBL.Name.Length < 2)
            {
                validstud = false;
                sb.Append(Environment.NewLine + "Student Name Invalid");

            }
            if (objstudBL.Class < 0)
            {
                validstud = false;
                sb.Append(Environment.NewLine + "Enter class ");
            }
            if (objstudBL.Mark < 0 || objstudBL.Mark > 100)
            {
                validstud = false;
                sb.Append(Environment.NewLine + "Invalid Mark ");
            }
            if (objstudBL.Address == string.Empty)
            {
                validstud = false;
                sb.Append(Environment.NewLine + "Address Required");
            }

            if (validstud == false)
                throw new StudExceptions(sb.ToString());

            return validstud;
        }
        //BL Method to insert data in product table using Stored Procedure 
        public static bool InsertBL(StudEntity objstud)
        {
            bool isInserted = false;
            try
            {
                if (IsInputValid(objstud))
                {
                    StudDAL studDAL = new StudDAL();
                    isInserted = studDAL.InsertDAL(objstud);

                }

            }
            catch (StudExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            return isInserted;
        }
        //BL Method to Update data in product table using Stored Procedure 

        public static bool UpdateBL(StudEntity objstud)
        {
            bool isUpdated = false;
            try
            {
                if (IsInputValid(objstud))
                {
                    StudDAL studDAL = new StudDAL();
                    isUpdated = studDAL.UpdateDAL(objstud);

                }

            }
            catch (StudExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            return isUpdated;
        }

        //BL Method to Delete data from product table using Stored Procedure

        public static bool DeleteBL(int ID)
        {
            bool isDeleted = false;
            try
            {

                StudDAL studDAL = new StudDAL();
                isDeleted = studDAL.DeleteDAL(ID);

            }
            catch (StudExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            return isDeleted;
        }

        //BL Method to Select and populate data from product table 

        public static List<StudEntity> SelectBL()
        {
            List<StudEntity> objstud = null;
            try
            {

                StudDAL studDL = new StudDAL();
                objstud = studDL.SelectDAL();

            }
            catch (StudExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
            return objstud;
        }
    }
}
