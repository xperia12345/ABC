﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

///<summary>
///      File                 : RetestManagementSystem
///      Author Name          : Kundan Maurya
///      Desc                 : Program to define the Entities of the project.
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

namespace Retest.Entities
{
    public class StudEntity
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Class { get; set; }
        public int Mark { get; set; }
        public string Gender { get; set; }
        public String Address { get; set; }
    }
}
