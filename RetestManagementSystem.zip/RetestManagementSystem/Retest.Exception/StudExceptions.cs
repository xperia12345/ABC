﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

///<summary>
///      File                 : RetestManagementSystem
///      Author Name          : Kundan Maurya
///      Desc                 : Manual Exceptions implemented
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

namespace Retest.Exceptions
{
    public class StudExceptions:ApplicationException
    {
        public StudExceptions()
             : base()
        {

        }
        public StudExceptions(string message)
        : base(message)
        {
        }
        public StudExceptions(string message, Exception objEx): base(message, objEx)
        {

        }
    }
}
