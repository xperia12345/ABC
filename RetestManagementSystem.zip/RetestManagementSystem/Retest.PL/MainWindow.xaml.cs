﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Restests.DAL;
using Retest.BAL;
using Retest.Entities;
using Retest.Exceptions;

///<summary>
///      File                 : RetestManagementSystem 
///      Author Name          : Kundan Maurya
///      Desc                 : Program to design WPF 
///      Version              : 1.0
///      Last Modified Date   : 05-Dec-2018
///      Change Description   : No changes implemented
///</summary>

namespace Retest.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        string gender;
        StudEntity proTemp = null;
        StudDAL dal = new StudDAL();
        public MainWindow()
        {
            InitializeComponent();
        }
       
        private bool IsValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (cmbProdName.Text == null | cmbProdName.Text == string.Empty | cmbProdName.Text.Length < 2)
            {
                sb.Append("\nStudent-Name is Mandatory!");
                isValid = false;
            }
            if (txtClass.Text == null | txtClass.Text == string.Empty | txtClass.Text.Length <0)
            {
                sb.Append("\nClass is Mandatory!");
                isValid = false;
            }
            if (txtMark.Text == null | txtMark.Text == string.Empty | txtMark.Text.Length < 0 )
            {
                sb.Append("\nMark is Mandatory!");
                isValid = false;
            }
            if (txtAddress.Text == null | txtAddress.Text == string.Empty | txtAddress.Text.Length < 1)
            {
                sb.Append("\nAddress is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new StudExceptions(sb.ToString());
            }

            return isValid;

        }
        //Button to Insert
        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                if (IsValid())
                {
                    proTemp = new StudEntity();

                    proTemp.Name = cmbProdName.Text;
                    proTemp.Class = Convert.ToInt32(txtClass.Text);
                    proTemp.Mark = Convert.ToInt32(txtMark.Text);
                    proTemp.Gender = gender.ToString();
                    proTemp.Address = txtAddress.Text;                  

                   

                    StudBAL.InsertBL(proTemp);
                    MessageBox.Show("Inserted Succesfully");
                    PopulateUI();
                }
            }
            catch (StudExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }
        
        //Button to Update

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               
                if (IsValid())
                {
                     proTemp = new StudEntity();
                    proTemp = (StudEntity)cmbProdName.SelectedItem;
                    proTemp.Name = cmbProdName.Text;
                    proTemp.Class = Convert.ToInt32(txtClass.Text);
                    proTemp.Mark = Convert.ToInt32(txtMark.Text);
                    proTemp.Gender = gender.ToString();
                    proTemp.Address = txtAddress.Text;                    
                    
                    StudBAL.UpdateBL(proTemp);
                    PopulateUI();
                    MessageBox.Show("Update Succesfully");
                    
                }
            }
            catch (StudExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        //Button to Delete

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
              try
              {
                  bool status = false;


                          int ID = Convert.ToInt32(txtID.Text);
                          status = StudBAL.DeleteBL(ID);
                             PopulateUI();
                MessageBox.Show("Deleted");

              }
              catch (StudExceptions ex)
              {
                  MessageBox.Show(ex.Message);
              }


        }

        //Button to Exit

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public void PopulateUI()
        {
            try
            {

                IEnumerable<StudEntity> prods = dal.SelectDAL();
                dgProducts.ItemsSource = prods;
                cmbProdName.ItemsSource = prods;
                cmbProdName.DisplayMemberPath = "Name";
            }
            catch (StudExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex2)
            {
                throw new StudExceptions(ex2.Message);
            }
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void TxtName_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        //Button to Clear

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            txtID.Text = "";
            cmbProdName.Text = "";
            txtClass.Text = "";
            txtMark.Text = "";
            txtAddress.Text = "";
            
            
            
        }
        //To choose Gender

        private void RdoMale_Click(object sender, RoutedEventArgs e)
        {
            if (rdoMale.IsChecked == true)
            {
                gender = rdoMale.Content.ToString();
            }
           

        }

        private void RdoFemale_Click(object sender, RoutedEventArgs e)
        {
            if (rdoFemale.IsChecked == true)
            {
                gender = rdoFemale.Content.ToString();
            }
        }
    }
}
