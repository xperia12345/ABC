﻿use Training_24Oct18_Pune

CREATE TABLE maurya.student
(ID INT IDENTITY (1,1) PRIMARY KEY NOT NULL,
Name varchar(30),
Class int,
Marks int,
Address nvarchar(50)
);
[‎12/‎22/‎2018 11:27 AM]  Ansari, Shariq Anwar Ahmed:  
 Regex reg = new Regex("/^[a-zA-Z]+$/"); ye BL me isInputValid ke function me
if (!reg.IsMatch(trainee.ModuleName.ToString()) & !trainee.ModuleName.Contains(" "))
            {
                IsTraineeValid = false;
                sb.Append(Environment.NewLine + "Module Name is not valid");

            } 
ye bhi
 



select * from maurya.student
--Store Procedure to Insert Value
DROP PROCEDURE Insert_maurya.student

create procedure Insert_student
@Name varchar(30),
@Class int,
@Marks int,
@Address nvarchar(50)
AS
begin
insert into maurya.student 
values(@Name,@Class,@Marks,@Address);
end;
exec Insert_student 'Kundan', 6 ,100, 'xyz'
exec Insert_student 'Time', 6 ,25, 'xydsgz'
exec Insert_student 'Samay', 7 ,50, 'xfsdgyz'
--Store Procedure to Update Value

DROP PROCEDURE Update_student

create procedure Update_student
@ID int,
@Name varchar(30),
@Class int,
@Marks int,
@Address nvarchar(50)
AS
begin
update maurya.student set 
Name=@Name,
Class=@Class,
Marks=@Marks,
Address=@Address
where ID =@ID;
end;
exec Update_student 10,'sa',2,12,'kbc'

--Store Procedure to Delete Value

DROP PROCEDURE Delete_student

CREATE PROCEDURE Delete_student
@ID int
AS
begin
delete from maurya.student
where ID=@Id;
end;


exec Delete_student 3

select * from maurya.student