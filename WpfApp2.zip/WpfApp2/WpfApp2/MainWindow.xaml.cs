﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;

        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }
        public void PopulateUI()
        {
            List<GUIEntity> prods = dbContext.GUIEntities.ToList();

            dgProducts.ItemsSource = prods;
            cmbProdName.ItemsSource = prods;
            cmbProdName.DisplayMemberPath = "ProdName";

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

           // GUIEntity p = (GUIEntity)cmbProdName.SelectedItem;
            GUIEntity prod = dbContext.GUIEntities.Single(p => p.Id == id);


            prod.ProdName = cmbProdName.Text;
            prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.ExpDate = Convert.ToDateTime(dpExpDate.Text);            
            dbContext.SaveChanges();
            MessageBox.Show("Updated");
            PopulateUI();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            GUIEntity prod = new GUIEntity();

            //Write the code to get data from controls & set to prperties  of GUIentities
            prod.ProdName = cmbProdName.Text;
            prod.Price = Convert.ToDecimal(txtPrice.Text);
            prod.ExpDate = Convert.ToDateTime(dpExpDate.Text);

            dbContext.GUIEntities.Add(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");
            PopulateUI();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int id = ((GUIEntity)cmbProdName.SelectedItem).Id;
            GUIEntity prod = dbContext.GUIEntities.Single(p => p.Id == id);

           // GUIEntity prod = (GUIEntity)cmbProdName.SelectedItem;

            //Complete above   code by writing LINQ to select single record based on primary key to get data from controls & set to prperties  of GUIentities


            dbContext.GUIEntities.Remove(prod);
            dbContext.SaveChanges();
            MessageBox.Show("Deleted");
            PopulateUI();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }
        int id;
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            id=((GUIEntity)cmbProdName.SelectedItem).Id;
        }
    }
}

  

        
                 
 
    
